/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author David
 */
abstract class VotosAbs {

    int votos;
    
    public int getVotos() {
    return votos;
    }
    
    public void setVotos1(int votos){
        this.votos = votos;
    }
    
    public abstract void setVotos();
}
